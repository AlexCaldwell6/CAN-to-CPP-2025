/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *WindowWidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *sunergyLogo;
    QWidget *LeftWidget;
    QVBoxLayout *verticalLayout_3;
    QWidget *SOCReport;
    QGridLayout *gridLayout_4;
    QLabel *SOCLabel;
    QLCDNumber *SOCValue;
    QWidget *SpeedWidget;
    QVBoxLayout *verticalLayout_5;
    QLabel *SpeedLabel;
    QLCDNumber *SpeedValue;
    QWidget *widget;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 480);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(800, 480));
        MainWindow->setMaximumSize(QSize(800, 480));
        QIcon icon;
        icon.addFile(QString::fromUtf8("images/sunergyIcon.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        WindowWidget = new QWidget(MainWindow);
        WindowWidget->setObjectName("WindowWidget");
        sizePolicy.setHeightForWidth(WindowWidget->sizePolicy().hasHeightForWidth());
        WindowWidget->setSizePolicy(sizePolicy);
        WindowWidget->setMaximumSize(QSize(800, 480));
        WindowWidget->setBaseSize(QSize(200, 100));
        WindowWidget->setStyleSheet(QString::fromUtf8(""));
        gridLayout_2 = new QGridLayout(WindowWidget);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout = new QGridLayout();
        gridLayout->setObjectName("gridLayout");
        gridLayout->setSizeConstraint(QLayout::SizeConstraint::SetDefaultConstraint);
        sunergyLogo = new QLabel(WindowWidget);
        sunergyLogo->setObjectName("sunergyLogo");
        sizePolicy.setHeightForWidth(sunergyLogo->sizePolicy().hasHeightForWidth());
        sunergyLogo->setSizePolicy(sizePolicy);
        sunergyLogo->setMinimumSize(QSize(200, 100));
        sunergyLogo->setMaximumSize(QSize(200, 100));
        sunergyLogo->setStyleSheet(QString::fromUtf8(""));
        sunergyLogo->setPixmap(QPixmap(QString::fromUtf8("images/sunergyLogo.png")));
        sunergyLogo->setScaledContents(true);
        sunergyLogo->setAlignment(Qt::AlignmentFlag::AlignCenter);

        gridLayout->addWidget(sunergyLogo, 0, 0, 1, 1);

        LeftWidget = new QWidget(WindowWidget);
        LeftWidget->setObjectName("LeftWidget");
        LeftWidget->setMinimumSize(QSize(0, 300));
        LeftWidget->setMaximumSize(QSize(16777215, 300));
        verticalLayout_3 = new QVBoxLayout(LeftWidget);
        verticalLayout_3->setObjectName("verticalLayout_3");
        SOCReport = new QWidget(LeftWidget);
        SOCReport->setObjectName("SOCReport");
        SOCReport->setMinimumSize(QSize(0, 100));
        gridLayout_4 = new QGridLayout(SOCReport);
        gridLayout_4->setObjectName("gridLayout_4");
        SOCLabel = new QLabel(SOCReport);
        SOCLabel->setObjectName("SOCLabel");

        gridLayout_4->addWidget(SOCLabel, 0, 0, 1, 1, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignTop);

        SOCValue = new QLCDNumber(SOCReport);
        SOCValue->setObjectName("SOCValue");

        gridLayout_4->addWidget(SOCValue, 1, 0, 1, 1);


        verticalLayout_3->addWidget(SOCReport);

        SpeedWidget = new QWidget(LeftWidget);
        SpeedWidget->setObjectName("SpeedWidget");
        verticalLayout_5 = new QVBoxLayout(SpeedWidget);
        verticalLayout_5->setObjectName("verticalLayout_5");
        SpeedLabel = new QLabel(SpeedWidget);
        SpeedLabel->setObjectName("SpeedLabel");

        verticalLayout_5->addWidget(SpeedLabel, 0, Qt::AlignmentFlag::AlignHCenter|Qt::AlignmentFlag::AlignTop);

        SpeedValue = new QLCDNumber(SpeedWidget);
        SpeedValue->setObjectName("SpeedValue");

        verticalLayout_5->addWidget(SpeedValue);


        verticalLayout_3->addWidget(SpeedWidget);


        gridLayout->addWidget(LeftWidget, 1, 0, 1, 1);

        widget = new QWidget(WindowWidget);
        widget->setObjectName("widget");

        gridLayout->addWidget(widget, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        MainWindow->setCentralWidget(WindowWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "GUI for Driver Interface", nullptr));
        sunergyLogo->setText(QString());
        SOCLabel->setText(QCoreApplication::translate("MainWindow", "State of Charge", nullptr));
        SpeedLabel->setText(QCoreApplication::translate("MainWindow", "Speedometer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
